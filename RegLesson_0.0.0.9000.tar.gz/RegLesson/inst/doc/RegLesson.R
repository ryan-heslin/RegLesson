## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = ""
)

## ---- eval = FALSE------------------------------------------------------------
#  devtools::install_github("ryan-heslin/RegLesson")

## ----setup--------------------------------------------------------------------
library(RegLesson)

X <- LinRegProblem(mtcars[, -1], mtcars$mpg)

## -----------------------------------------------------------------------------
do_problems(
  X,
  regression_relation(),
  Working_Hoteling(X_h = cbind(1, as.matrix(mtcars[, -1])))
)

